﻿namespace P01_StudentSystem
{
    internal class StartUp
    {
        static void Main()
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
