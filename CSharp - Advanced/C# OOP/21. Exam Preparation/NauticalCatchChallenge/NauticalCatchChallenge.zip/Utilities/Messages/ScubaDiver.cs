﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NauticalCatchChallenge.Utilities.Messages
{
    public class ScubaDiver : Diver
    {
        private const int ScubaDiverBaseOxygenLevel = 540;

        public ScubaDiver(string name) : base(name, ScubaDiverBaseOxygenLevel)
        {
        }

        public override void Miss(int TimeToCatch)
        {
            OxygenLevel -= (int)Math.Round(TimeToCatch * 0.3, MidpointRounding.AwayFromZero);
        }

        public override void RenewOxy()
        {
            OxygenLevel = ScubaDiverBaseOxygenLevel;
        }
    }
}
